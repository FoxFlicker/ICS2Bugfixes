Internet Cafe Simulator 2 Bug Fixes

07/15/2024
• Fixed Kawaii Coins subtracting from money on sale.