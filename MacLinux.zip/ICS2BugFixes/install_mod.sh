#!/bin/bash

# Prompt user for the game's Managed folder path
echo "Please enter the path to your game's Managed folder (e.g., ~/Library/Application Support/Steam/steamapps/common/Internet Cafe Simulator 2/Internet Cafe Simulator 2_Data/Managed or ~/.local/share/Steam/steamapps/common/Internet Cafe Simulator 2/Internet Cafe Simulator 2_Data/Managed):"
read GAME_DIR

# Set mod directory to the directory where this script is located
MOD_DIR="$(dirname "$0")/Managed"

# Check if the game's Assembly-CSharp.dll exists
if [ ! -f "$GAME_DIR/Assembly-CSharp.dll" ]; then
    echo "The path you entered is invalid or does not contain Assembly-CSharp.dll."
    exit 1
fi

# Check if the mod's Assembly-CSharp.dll exists
if [ ! -f "$MOD_DIR/Assembly-CSharp.dll" ]; then
    echo "Could not find the mod's Assembly-CSharp.dll. Try extracting the zipped folder again."
    exit 1
fi

# Create a backup of the game's Assembly-CSharp.dll
echo "Backing up original Assembly-CSharp.dll..."
cp "$GAME_DIR/Assembly-CSharp.dll" "$GAME_DIR/Assembly-CSharp.dll.bak"

# Copy the mod's Assembly-CSharp.dll to the game's directory
echo "Copying mod files..."
cp "$MOD_DIR/Assembly-CSharp.dll" "$GAME_DIR/Assembly-CSharp.dll"

echo "Installation complete!"
